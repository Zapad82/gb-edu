package OOP.Lessons.Lesson1.Ex002;

public class Point2D  {
    int x, y;
    
}
