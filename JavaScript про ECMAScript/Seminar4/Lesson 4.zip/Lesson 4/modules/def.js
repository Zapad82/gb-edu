export function def(a, b) {
	return a - b;
}

export const data = [1, 3, 34, 6, 7, 4];
