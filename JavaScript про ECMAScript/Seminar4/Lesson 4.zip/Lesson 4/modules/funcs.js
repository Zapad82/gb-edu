const mult = (a, b) => a * b;
const div = (a, b) => a / b;

export default { mult, div };
