const add = (a, b) => a + b;

export default add;
