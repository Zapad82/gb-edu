<template>
  <div>
<!--    <CounterComp />-->
<!--    <header>-->
<!--      <CartItems type="header"/>-->
<!--    </header>-->
<!--    <footer>-->
<!--      <CartItems type="footer"/>-->
<!--    </footer>-->
    <CartItems/>
  </div>
</template>
<script>
// import CounterComp from "@/components/CounterComp.vue";

import CartItems from "@/components/CartItems.vue";

export default {
  components: {
    CartItems
    // CounterComp
  },
  data() {
    return {

    }
  },
  computed: {
  }
}
</script>
