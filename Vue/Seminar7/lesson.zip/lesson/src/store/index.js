// import Vuex from "vuex";
// import Vue from "vue";
//
// Vue.use(Vuex);
//
// const store = new Vuex.Store({
//     state: {
//         count: 0
//     },
//     mutations: {
//         INCREMENT (state) {
//             state.count++
//         },
//         DECREMENT (state) {
//             state.count--
//         }
//     }
// })
//
// export default store;


export default {
    state: {
        // count: 0,
        cartItems: [],
    },
    getters: {
        cartItems(state) {
            return state.cartItems;
        },
        totalPrice(state) {
            return state
                .cartItems
                .reduce((totalPrice, item, ) => totalPrice + item.quantity * item.price, 0)
        },
        totalItems(state) {
            return state
                .cartItems
                .reduce((totalQuantity, item, ) => totalQuantity + item.quantity, 0)
        }
    },
    mutations: {
        ADD_ITEM_TO_CART(state, item) {
            const find = state
                .cartItems
                .find((stateItem) => stateItem.id === item.id);

            if (find) {
                find.quantity++;
            } else {
                const newItem = {
                    ...item,
                    quantity: 1,
                };

                state.cartItems.push(newItem)
            }
        },
        SET_CART(state, cart) {
            state.cartItems = cart;
        }
        // INCREMENT (state) {
        //     state.count++
        // },
        // DECREMENT (state) {
        //     state.count--
        // }
    },
    actions: {
        addToCart({commit}, item) {
            commit('ADD_ITEM_TO_CART', item);
        },
        getCart({commit}) {
            setTimeout(() => {
                const cart = [
                    {
                        id: 1,
                        name: 'Товар 1',
                        price: 100,
                        quantity: 3,
                    },
                    {
                        id: 2,
                        name: 'Товар 2',
                        price: 50,
                        quantity: 2,
                    },
                    {
                        id: 3,
                        name: 'Товар 3',
                        price: 200,
                        quantity: 1,
                    },
                ];

                commit('SET_CART', cart);
            }, 1500);
        }
    }
}
