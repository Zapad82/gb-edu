<script>
import { mapState, mapMutations } from "vuex";

export default {
  name: "CounterComp",
  methods: {
    ...mapMutations(['INCREMENT', 'DECREMENT']),
    // increase() {
    //   this.$store.commit('increment')
    // },
    // decrease() {
    //   this.$store.commit('decrement')
    // },
  },
  computed: {
    ...mapState(['count']),
    // counter() {
    //   return this.$store.state.count
    // }
  }
}
</script>

<template>
    <div>
<!--      <p>{{ counter }}</p>-->
      <p>{{ count }}</p>
<!--      <button @click="increase">+</button>-->
<!--      <button @click="decrease">-</button>-->
      <button @click="INCREMENT">+</button>
      <button @click="DECREMENT">-</button>
    </div>
</template>

<style scoped>

</style>
