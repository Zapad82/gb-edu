<template>
  <div>
    <h2>{{ project.title }}</h2>
    <p>{{ project.description }}</p>
    <SliderBlock :slides="project.slides" />
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import SliderBlock from '../blocks/SliderBlock.vue'

export default {
  components: {
    SliderBlock
  },
  computed: {
    ...mapGetters('projects', ['projectById'])
  },
  created () {
    this.$store.dispatch('fetchProjects')
  },
  data () {
    return {
      project: {}
    }
  },
  watch: {
    '$route.params.id': function (id) {
      this.project = this.projectById(id)
    }
  }
}
</script>

<!-- <template>
  <div>
    <div class="container">
      <div class="project-details">
        <div class="project-details__text">
          <div
          v-for="info in PROJECTINFO"
          :key="info"
          class="project-details__content"
          >
          <h2 class="project-details__title">
            {{ info.heading }}
          </h2>
          <div class="project-details__text-box">
            <p class="project-details__subtitle">
              {{ info.firstparagraph }}
            </p><br><br>
            <p class="project-details__subtitle">
              {{ info.secondparagraph }}
            </p>
          </div>
        </div>
        <div class="project-details__slider">
          <SliderBlock />
        </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import SliderBlock from '@/components/blocks/SliderBlock.vue'
// import { mapState } from 'vuex'

export default {
  name: 'ProjectDetails',

  components: {
    SliderBlock
  }
  // computed: {
  //   ...mapState(['PROJECTINFO', 'SLIDERPICTURES'])
  // }
}

//   name: 'ProjectDetails',

//   data () {
//     return {
//     }
//   },

//   components: {
//     SliderBlock
//   },

//   computed: {
//     ...mapState(['projectInfo', 'sliderPictures'])
//   },

//   mounted () {
//   },

//   methods: {
//   }
//
</script>

<style lang="scss" scoped>
</style> -->
