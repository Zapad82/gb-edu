import Vue from 'vue'
import Vuex from 'vuex'
// import { createStore } from 'vuex'
import projectsModule from './modules/projects'
Vue.use(Vuex)
export default new Vuex.Store({
  modules: {
    projects: projectsModule
  }
})

// const projectsModule = {
//   state: {
//     projects: []
//   },
//   mutations: {
//     setProjects (state, projects) {
//       state.projects = projects
//     }
//   },
//   actions: {
//     fetchProjects ({ commit }) {
//       const projects = [
//         {
//           id: 1,
//           title: 'Project 1',
//           description: 'Description for project 1',
//           image: 'https://via.placeholder.com/300x200',
//           slides: [
//             'https://via.placeholder.com/600x400',
//             'https://via.placeholder.com/600x400',
//             'https://via.placeholder.com/600x400'
//           ]
//         },
//         {
//           id: 2,
//           title: 'Project 2',
//           description: 'Description for project 2',
//           image: 'https://via.placeholder.com/300x200',
//           slides: [
//             'https://via.placeholder.com/600x400',
//             'https://via.placeholder.com/600x400',
//             'https://via.placeholder.com/600x400'
//           ]
//         }
//       ]
//       commit('setProjects', projects)
//     }
//   },
//   getters: {
//     projects (state) {
//       return state.projects
//     },
//     projectById: (state) => (id) => {
//       return state.projects.find(project => project.id === id)
//     }
//   }
// }

// export default projectsModule
// export default createStore({
//   state: {
//     projectInfo: [
//       {
//         heading: 'Minimal Look Bedrooms',
//         firstparagraph: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquamsem vitae turpis dignissim maximus. Aliquam sollicitudin tellumassa, vbel maximus purus posuere in. Dojrices gravida dignissim. Praesent at nibh in mi fringilla mattis. Phasellus ut dolor odio. Aenean in the ipsum vel lectus bibendum commodo.',
//         secondparagraph: 'In nec sem suscipit, convallis leo vitae, lacinia nibh. Cras amet tellus lectus. Vivamus ipsum nunc, mattis quis nibh id, pellentesque arcu. Donec a pellentesque Cras erat enim, gravida non ante vitae,elequis convallis elit, in viverra felis. Donec ultrices tellus vitae iaculisvd porta. Proin tincidunt ligula id purus porttitor.'
//       }
//     ],
//     //     sliderPictures: [
//     //   { id: '1', src: '@/assets/img/content/Photo1Block2.jpg', caption: 'slider pic' },
//     //   { id: '2', src: '@/assets/img/content/Photo1Block3.png', caption: 'slider pic' },
//     //   { id: '3', src: '@/assets/img/content/Photo3Block3.png', caption: 'slider pic' }
//     // ],

//     sliderPictures: [
//       {
//         src: '@/assets/img/content/Photo1Block2.jpg',
//         caption: 'First slide'
//       },
//       {
//         src: '@/assets/img/content/Photo1Block2.jpg',
//         caption: 'Second slide'
//       },
//       {
//         src: '@/assets/img/content/Photo1Block2.jpg',
//         caption: 'Third slide'
//       }
//     ]
//   },

//   getters: {
//     PROJECTINFO: state => {
//       return state.projectInfo
//     },
//     SLIDERPICTURES: state => {
//       return state.sliderPictures
//     }
//   },

//   mutations: {
//     // SET_PROJECT (state, project)
//   },

//   actions: {
//   },

//   modules: {
//   }
// })
