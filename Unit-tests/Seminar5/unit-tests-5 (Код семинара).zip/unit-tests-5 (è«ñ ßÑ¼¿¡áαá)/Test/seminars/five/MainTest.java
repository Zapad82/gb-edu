package seminars.five;

class MainTest {
    //5.1.

    //5.2.

    //5.3.
}