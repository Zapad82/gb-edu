package seminars.five;



public class SeleniumTest {

}
