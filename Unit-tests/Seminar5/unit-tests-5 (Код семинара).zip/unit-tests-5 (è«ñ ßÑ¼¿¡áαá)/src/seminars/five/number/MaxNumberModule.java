package seminars.five.number;

import java.util.List;

public class MaxNumberModule {

}
