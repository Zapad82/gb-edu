package seminars.five.order;

public class PaymentService {
    public boolean processPayment(String orderId, double amount) {
        // Здесь обычно был бы код для обработки платежей, но для примера просто возвращаем true
        return true;
    }
}
