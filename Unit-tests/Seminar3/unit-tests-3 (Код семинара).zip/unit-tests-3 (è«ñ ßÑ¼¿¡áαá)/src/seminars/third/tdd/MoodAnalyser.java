package seminars.third.tdd;

public class MoodAnalyser {

    public String analyseMood(String message) {
        return "";
    }

}