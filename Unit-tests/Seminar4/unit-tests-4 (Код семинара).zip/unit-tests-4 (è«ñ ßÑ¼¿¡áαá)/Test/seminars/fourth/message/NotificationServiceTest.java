package seminars.fourth.message;



class NotificationServiceTest {

}