package seminars.fourth.book;



class BookServiceTest {

}