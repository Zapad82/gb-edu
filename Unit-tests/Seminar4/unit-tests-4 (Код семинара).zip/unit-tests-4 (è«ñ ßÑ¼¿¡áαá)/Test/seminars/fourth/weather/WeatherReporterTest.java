package seminars.fourth.weather;


class WeatherReporterTest {


}