package seminars.fourth.hotel;


class BookingServiceTest {

}