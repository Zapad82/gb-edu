package seminars.fourth.database;



class DataProcessorTest {

}