package seminars.fourth.message;

public class MessageService {
    public void sendMessage(String message, String recipient) {
        // Здесь код, который отправляет сообщение получателю.
        System.out.println("Отправка сообщения \"" + message + "\" получателю " + recipient);
    }
}
