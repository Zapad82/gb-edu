/*
Дано число. Проверить кратно ли оно 7 и 23 
*/
// var n = Int(readLine()!)!
// var flag = n % 7 == 0 && n % 23 == 0
// print(flag)


var n = Int(readLine()!)!
print(n % 7 == 0 && n % 23 == 0)
